import tkinter as tk
from classes.DBInterface import DBInterface
from classes.GUI import GUI

if __name__ == '__main__':
    DBInterface = DBInterface()
    root = tk.Tk()
    GUI = GUI(root)

    root.mainloop()
